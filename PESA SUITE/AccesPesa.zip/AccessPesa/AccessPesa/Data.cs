﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessPesa
{
    class Data
    {

        private String customer_name;
        private float float_Balance;


        public Data(String cn,float fb) {
            this.customer_name = cn;
            this.float_Balance = fb;


        
        
        
        }



    }
}
