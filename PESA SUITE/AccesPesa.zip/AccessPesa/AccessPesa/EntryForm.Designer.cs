﻿namespace AccessPesa
{
    partial class EntryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TransactionIdLabel = new System.Windows.Forms.Label();
            this.TransactionId_TextBox = new System.Windows.Forms.TextBox();
            this.TRANSACTIONBOX = new System.Windows.Forms.GroupBox();
            this.Alert3 = new System.Windows.Forms.Label();
            this.Alert2 = new System.Windows.Forms.Label();
            this.Alert1 = new System.Windows.Forms.Label();
            this.TransactionValue_TextBox = new System.Windows.Forms.TextBox();
            this.TransactionValueLabel = new System.Windows.Forms.Label();
            this.PokeaButton = new System.Windows.Forms.RadioButton();
            this.ToaButton = new System.Windows.Forms.RadioButton();
            this.Transactiontypelabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Alert7 = new System.Windows.Forms.Label();
            this.Alert6 = new System.Windows.Forms.Label();
            this.Alert5 = new System.Windows.Forms.Label();
            this.Alert4 = new System.Windows.Forms.Label();
            this.CustomerIdTypeLabel = new System.Windows.Forms.Label();
            this.CustomerIdType_TextBox = new System.Windows.Forms.TextBox();
            this.CustomerNameLabel = new System.Windows.Forms.Label();
            this.CustomerName_TextBox = new System.Windows.Forms.TextBox();
            this.CustomerIDLabel = new System.Windows.Forms.Label();
            this.CustomerIdNo_TextBox = new System.Windows.Forms.TextBox();
            this.CustomerCellLabel = new System.Windows.Forms.Label();
            this.CustomerCellPhone_TextBox = new System.Windows.Forms.TextBox();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.AlertMain = new System.Windows.Forms.Label();
            this.TRANSACTIONBOX.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(81, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // TransactionIdLabel
            // 
            this.TransactionIdLabel.AutoSize = true;
            this.TransactionIdLabel.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionIdLabel.ForeColor = System.Drawing.Color.White;
            this.TransactionIdLabel.Location = new System.Drawing.Point(6, 27);
            this.TransactionIdLabel.Name = "TransactionIdLabel";
            this.TransactionIdLabel.Size = new System.Drawing.Size(134, 21);
            this.TransactionIdLabel.TabIndex = 2;
            this.TransactionIdLabel.Text = "TRANSACTION ID";
            // 
            // TransactionId_TextBox
            // 
            this.TransactionId_TextBox.Location = new System.Drawing.Point(178, 27);
            this.TransactionId_TextBox.Name = "TransactionId_TextBox";
            this.TransactionId_TextBox.Size = new System.Drawing.Size(168, 25);
            this.TransactionId_TextBox.TabIndex = 3;
            // 
            // TRANSACTIONBOX
            // 
            this.TRANSACTIONBOX.Controls.Add(this.Alert3);
            this.TRANSACTIONBOX.Controls.Add(this.Alert2);
            this.TRANSACTIONBOX.Controls.Add(this.Alert1);
            this.TRANSACTIONBOX.Controls.Add(this.TransactionValue_TextBox);
            this.TRANSACTIONBOX.Controls.Add(this.TransactionValueLabel);
            this.TRANSACTIONBOX.Controls.Add(this.PokeaButton);
            this.TRANSACTIONBOX.Controls.Add(this.ToaButton);
            this.TRANSACTIONBOX.Controls.Add(this.Transactiontypelabel);
            this.TRANSACTIONBOX.Controls.Add(this.TransactionIdLabel);
            this.TRANSACTIONBOX.Controls.Add(this.TransactionId_TextBox);
            this.TRANSACTIONBOX.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TRANSACTIONBOX.ForeColor = System.Drawing.Color.White;
            this.TRANSACTIONBOX.Location = new System.Drawing.Point(12, 89);
            this.TRANSACTIONBOX.Name = "TRANSACTIONBOX";
            this.TRANSACTIONBOX.Size = new System.Drawing.Size(443, 197);
            this.TRANSACTIONBOX.TabIndex = 4;
            this.TRANSACTIONBOX.TabStop = false;
            this.TRANSACTIONBOX.Text = "TRANSACTION QUERY";
            // 
            // Alert3
            // 
            this.Alert3.AutoSize = true;
            this.Alert3.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alert3.ForeColor = System.Drawing.Color.White;
            this.Alert3.Location = new System.Drawing.Point(387, 147);
            this.Alert3.Name = "Alert3";
            this.Alert3.Size = new System.Drawing.Size(26, 17);
            this.Alert3.TabIndex = 11;
            this.Alert3.Text = "***";
            this.Alert3.Visible = false;
            // 
            // Alert2
            // 
            this.Alert2.AutoSize = true;
            this.Alert2.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alert2.ForeColor = System.Drawing.Color.White;
            this.Alert2.Location = new System.Drawing.Point(387, 92);
            this.Alert2.Name = "Alert2";
            this.Alert2.Size = new System.Drawing.Size(26, 17);
            this.Alert2.TabIndex = 10;
            this.Alert2.Text = "***";
            this.Alert2.Visible = false;
            // 
            // Alert1
            // 
            this.Alert1.AutoSize = true;
            this.Alert1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alert1.ForeColor = System.Drawing.Color.White;
            this.Alert1.Location = new System.Drawing.Point(387, 32);
            this.Alert1.Name = "Alert1";
            this.Alert1.Size = new System.Drawing.Size(26, 17);
            this.Alert1.TabIndex = 9;
            this.Alert1.Text = "***";
            this.Alert1.Visible = false;
            // 
            // TransactionValue_TextBox
            // 
            this.TransactionValue_TextBox.Location = new System.Drawing.Point(178, 144);
            this.TransactionValue_TextBox.Name = "TransactionValue_TextBox";
            this.TransactionValue_TextBox.Size = new System.Drawing.Size(168, 25);
            this.TransactionValue_TextBox.TabIndex = 8;
            // 
            // TransactionValueLabel
            // 
            this.TransactionValueLabel.AutoSize = true;
            this.TransactionValueLabel.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionValueLabel.ForeColor = System.Drawing.Color.White;
            this.TransactionValueLabel.Location = new System.Drawing.Point(6, 144);
            this.TransactionValueLabel.Name = "TransactionValueLabel";
            this.TransactionValueLabel.Size = new System.Drawing.Size(166, 21);
            this.TransactionValueLabel.TabIndex = 7;
            this.TransactionValueLabel.Text = "TRANSACTION VALUE";
            // 
            // PokeaButton
            // 
            this.PokeaButton.AutoSize = true;
            this.PokeaButton.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PokeaButton.Location = new System.Drawing.Point(187, 90);
            this.PokeaButton.Name = "PokeaButton";
            this.PokeaButton.Size = new System.Drawing.Size(66, 21);
            this.PokeaButton.TabIndex = 6;
            this.PokeaButton.TabStop = true;
            this.PokeaButton.Text = "POKEA";
            this.PokeaButton.UseVisualStyleBackColor = true;
            // 
            // ToaButton
            // 
            this.ToaButton.AutoSize = true;
            this.ToaButton.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToaButton.Location = new System.Drawing.Point(285, 90);
            this.ToaButton.Name = "ToaButton";
            this.ToaButton.Size = new System.Drawing.Size(51, 21);
            this.ToaButton.TabIndex = 5;
            this.ToaButton.TabStop = true;
            this.ToaButton.Text = "TOA";
            this.ToaButton.UseVisualStyleBackColor = true;
            // 
            // Transactiontypelabel
            // 
            this.Transactiontypelabel.AutoSize = true;
            this.Transactiontypelabel.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Transactiontypelabel.ForeColor = System.Drawing.Color.White;
            this.Transactiontypelabel.Location = new System.Drawing.Point(6, 87);
            this.Transactiontypelabel.Name = "Transactiontypelabel";
            this.Transactiontypelabel.Size = new System.Drawing.Size(153, 21);
            this.Transactiontypelabel.TabIndex = 4;
            this.Transactiontypelabel.Text = "TRANSACTION TYPE";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Alert7);
            this.groupBox1.Controls.Add(this.Alert6);
            this.groupBox1.Controls.Add(this.Alert5);
            this.groupBox1.Controls.Add(this.Alert4);
            this.groupBox1.Controls.Add(this.CustomerIdTypeLabel);
            this.groupBox1.Controls.Add(this.CustomerIdType_TextBox);
            this.groupBox1.Controls.Add(this.CustomerNameLabel);
            this.groupBox1.Controls.Add(this.CustomerName_TextBox);
            this.groupBox1.Controls.Add(this.CustomerIDLabel);
            this.groupBox1.Controls.Add(this.CustomerIdNo_TextBox);
            this.groupBox1.Controls.Add(this.CustomerCellLabel);
            this.groupBox1.Controls.Add(this.CustomerCellPhone_TextBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 311);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(443, 197);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CUSTOMER QUERY";
            // 
            // Alert7
            // 
            this.Alert7.AutoSize = true;
            this.Alert7.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alert7.ForeColor = System.Drawing.Color.White;
            this.Alert7.Location = new System.Drawing.Point(399, 155);
            this.Alert7.Name = "Alert7";
            this.Alert7.Size = new System.Drawing.Size(26, 17);
            this.Alert7.TabIndex = 15;
            this.Alert7.Text = "***";
            this.Alert7.Visible = false;
            // 
            // Alert6
            // 
            this.Alert6.AutoSize = true;
            this.Alert6.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alert6.ForeColor = System.Drawing.Color.White;
            this.Alert6.Location = new System.Drawing.Point(399, 113);
            this.Alert6.Name = "Alert6";
            this.Alert6.Size = new System.Drawing.Size(26, 17);
            this.Alert6.TabIndex = 14;
            this.Alert6.Text = "***";
            this.Alert6.Visible = false;
            // 
            // Alert5
            // 
            this.Alert5.AutoSize = true;
            this.Alert5.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alert5.ForeColor = System.Drawing.Color.White;
            this.Alert5.Location = new System.Drawing.Point(399, 69);
            this.Alert5.Name = "Alert5";
            this.Alert5.Size = new System.Drawing.Size(26, 17);
            this.Alert5.TabIndex = 13;
            this.Alert5.Text = "***";
            this.Alert5.Visible = false;
            // 
            // Alert4
            // 
            this.Alert4.AutoSize = true;
            this.Alert4.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alert4.ForeColor = System.Drawing.Color.White;
            this.Alert4.Location = new System.Drawing.Point(399, 29);
            this.Alert4.Name = "Alert4";
            this.Alert4.Size = new System.Drawing.Size(26, 17);
            this.Alert4.TabIndex = 12;
            this.Alert4.Text = "***";
            this.Alert4.Visible = false;
            // 
            // CustomerIdTypeLabel
            // 
            this.CustomerIdTypeLabel.AutoSize = true;
            this.CustomerIdTypeLabel.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerIdTypeLabel.ForeColor = System.Drawing.Color.White;
            this.CustomerIdTypeLabel.Location = new System.Drawing.Point(6, 150);
            this.CustomerIdTypeLabel.Name = "CustomerIdTypeLabel";
            this.CustomerIdTypeLabel.Size = new System.Drawing.Size(149, 21);
            this.CustomerIdTypeLabel.TabIndex = 10;
            this.CustomerIdTypeLabel.Text = "CUSTOMER ID TYPE";
            // 
            // CustomerIdType_TextBox
            // 
            this.CustomerIdType_TextBox.Location = new System.Drawing.Point(225, 152);
            this.CustomerIdType_TextBox.Name = "CustomerIdType_TextBox";
            this.CustomerIdType_TextBox.Size = new System.Drawing.Size(168, 25);
            this.CustomerIdType_TextBox.TabIndex = 11;
            // 
            // CustomerNameLabel
            // 
            this.CustomerNameLabel.AutoSize = true;
            this.CustomerNameLabel.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerNameLabel.ForeColor = System.Drawing.Color.White;
            this.CustomerNameLabel.Location = new System.Drawing.Point(6, 24);
            this.CustomerNameLabel.Name = "CustomerNameLabel";
            this.CustomerNameLabel.Size = new System.Drawing.Size(140, 21);
            this.CustomerNameLabel.TabIndex = 8;
            this.CustomerNameLabel.Text = "CUSTOMER NAME";
            // 
            // CustomerName_TextBox
            // 
            this.CustomerName_TextBox.Location = new System.Drawing.Point(225, 24);
            this.CustomerName_TextBox.Name = "CustomerName_TextBox";
            this.CustomerName_TextBox.Size = new System.Drawing.Size(168, 25);
            this.CustomerName_TextBox.TabIndex = 9;
            // 
            // CustomerIDLabel
            // 
            this.CustomerIDLabel.AutoSize = true;
            this.CustomerIDLabel.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerIDLabel.ForeColor = System.Drawing.Color.White;
            this.CustomerIDLabel.Location = new System.Drawing.Point(6, 108);
            this.CustomerIDLabel.Name = "CustomerIDLabel";
            this.CustomerIDLabel.Size = new System.Drawing.Size(142, 21);
            this.CustomerIDLabel.TabIndex = 6;
            this.CustomerIDLabel.Text = "CUSTOMER ID NO.";
            // 
            // CustomerIdNo_TextBox
            // 
            this.CustomerIdNo_TextBox.Location = new System.Drawing.Point(225, 108);
            this.CustomerIdNo_TextBox.Name = "CustomerIdNo_TextBox";
            this.CustomerIdNo_TextBox.Size = new System.Drawing.Size(168, 25);
            this.CustomerIdNo_TextBox.TabIndex = 7;
            // 
            // CustomerCellLabel
            // 
            this.CustomerCellLabel.AutoSize = true;
            this.CustomerCellLabel.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerCellLabel.ForeColor = System.Drawing.Color.White;
            this.CustomerCellLabel.Location = new System.Drawing.Point(6, 64);
            this.CustomerCellLabel.Name = "CustomerCellLabel";
            this.CustomerCellLabel.Size = new System.Drawing.Size(213, 21);
            this.CustomerCellLabel.TabIndex = 4;
            this.CustomerCellLabel.Text = "CUSTOMER CELLPHONE NO.";
            // 
            // CustomerCellPhone_TextBox
            // 
            this.CustomerCellPhone_TextBox.Location = new System.Drawing.Point(225, 64);
            this.CustomerCellPhone_TextBox.Name = "CustomerCellPhone_TextBox";
            this.CustomerCellPhone_TextBox.Size = new System.Drawing.Size(168, 25);
            this.CustomerCellPhone_TextBox.TabIndex = 5;
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(380, 529);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(75, 23);
            this.SubmitButton.TabIndex = 6;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(283, 529);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(75, 23);
            this.ResetButton.TabIndex = 7;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(22, 529);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(75, 23);
            this.BackButton.TabIndex = 8;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(22, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // AlertMain
            // 
            this.AlertMain.AutoSize = true;
            this.AlertMain.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AlertMain.ForeColor = System.Drawing.Color.White;
            this.AlertMain.Location = new System.Drawing.Point(226, 69);
            this.AlertMain.Name = "AlertMain";
            this.AlertMain.Size = new System.Drawing.Size(223, 17);
            this.AlertMain.TabIndex = 12;
            this.AlertMain.Text = "ERROR ON INPUT FIELDS WITH ***";
            this.AlertMain.Visible = false;
            // 
            // EntryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(467, 564);
            this.Controls.Add(this.AlertMain);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TRANSACTIONBOX);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EntryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EntryForm";
            this.Load += new System.EventHandler(this.EntryForm_Load);
            this.TRANSACTIONBOX.ResumeLayout(false);
            this.TRANSACTIONBOX.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label TransactionIdLabel;
        private System.Windows.Forms.TextBox TransactionId_TextBox;
        private System.Windows.Forms.GroupBox TRANSACTIONBOX;
        private System.Windows.Forms.RadioButton PokeaButton;
        private System.Windows.Forms.RadioButton ToaButton;
        private System.Windows.Forms.Label Transactiontypelabel;
        private System.Windows.Forms.TextBox TransactionValue_TextBox;
        private System.Windows.Forms.Label TransactionValueLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label CustomerNameLabel;
        private System.Windows.Forms.TextBox CustomerName_TextBox;
        private System.Windows.Forms.Label CustomerIDLabel;
        private System.Windows.Forms.TextBox CustomerIdNo_TextBox;
        private System.Windows.Forms.Label CustomerCellLabel;
        private System.Windows.Forms.TextBox CustomerCellPhone_TextBox;
        private System.Windows.Forms.Label CustomerIdTypeLabel;
        private System.Windows.Forms.TextBox CustomerIdType_TextBox;
        private System.Windows.Forms.Label Alert3;
        private System.Windows.Forms.Label Alert2;
        private System.Windows.Forms.Label Alert1;
        private System.Windows.Forms.Label Alert7;
        private System.Windows.Forms.Label Alert6;
        private System.Windows.Forms.Label Alert5;
        private System.Windows.Forms.Label Alert4;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label AlertMain;
    }
}