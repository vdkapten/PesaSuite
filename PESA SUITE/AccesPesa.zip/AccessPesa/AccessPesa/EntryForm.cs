﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccessPesa
{
    public partial class EntryForm : Form
    {
        public Airtel_Money formtoairtel;
        public Ezy_Pesa formtoezy;
        public Tigo_Pesa formtotigo;
        public Vodacom_Mpesa formtovoda;
        public CRDB_Bank formtocrdb;
        public String from;
        public EntryForm()
        {
            InitializeComponent();
        }

        public void setBelonging(String f){
            from = f;
        }
        private void EntryForm_Load(object sender, EventArgs e)
        {
            switch (from)
            {
                case "airtel":
                    label1.Text = "AIRTEL MONEY FORM";
                    this.BackColor = Color.DarkRed;
                    break;
                case "ezy":
                    label1.Text = "EZYPESA FORM";
                    this.BackColor = Color.DarkGreen;
                    break;
                case "tigo":
                    label1.Text = "TIGO PESA FORM";
                    this.BackColor = Color.SteelBlue;
                    break;
                case "voda":
                    label1.Text = "VODACOM M-PESA FORM";
                    this.BackColor = Color.DarkRed;
                    break;
                case "crdb":
                    label1.Text = "CRDB BANK FORM";
                    this.BackColor = Color.SeaGreen;
                    break;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
           /*
            obj [] labels = new String[] {"TransactionId_TextBox"};

            foreach (String field in labels){
                field.Text = "";
            }
           
            foreach (Control x in this.Controls)
            {
                if (x is TextBox)
                {
                    ((TextBox)x).Text = String.Empty;
                }
            }*/
            DialogResult dialogResult = MessageBox.Show("Reset your Form?", "Reset?", MessageBoxButtons.YesNo);
            
            if (dialogResult == DialogResult.Yes)
            {
                TransactionId_TextBox.Text = "";
                TransactionValue_TextBox.Text = "";
                CustomerCellPhone_TextBox.Text = "";
                CustomerIdNo_TextBox.Text = "";
                CustomerIdType_TextBox.Text = "";
                CustomerName_TextBox.Text = "";
                PokeaButton.Checked = false;
                ToaButton.Checked = false;
            }
            
        }
    }
}
